<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
  </head>
  <body>

    <form class="login" action="index.php?action=login" method="post">

    Benutzername:<input type="text" name="user" value="Max">
    Passwort:<input type="password" name="password">
    <input type="submit" value="Send">

    </form>


  </body>
</html>
