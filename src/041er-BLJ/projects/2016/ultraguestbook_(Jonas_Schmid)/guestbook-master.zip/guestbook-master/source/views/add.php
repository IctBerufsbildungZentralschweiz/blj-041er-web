<?php 
echo '<h1>View: add</h1>';