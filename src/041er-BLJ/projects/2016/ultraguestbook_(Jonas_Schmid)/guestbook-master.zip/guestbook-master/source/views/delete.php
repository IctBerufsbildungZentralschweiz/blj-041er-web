<?php 
echo '<h1>View: delete</h1>';