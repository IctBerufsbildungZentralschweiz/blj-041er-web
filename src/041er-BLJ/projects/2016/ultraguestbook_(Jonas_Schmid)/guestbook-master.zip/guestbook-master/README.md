# guestbook
Mit diesem Gästebuch können normale Seitenbesucher einfach Einträge erstellen. Angemeldete Benutzer können Einträge erstellen und die eigenen bearbeiten und löschen.
