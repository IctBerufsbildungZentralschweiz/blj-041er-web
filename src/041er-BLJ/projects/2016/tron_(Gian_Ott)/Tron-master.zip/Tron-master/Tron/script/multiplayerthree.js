var c = document.getElementById("playGround");
var ctx = c.getContext("2d");
var number;
var output = [ ];

ctx.fillStyle = "white";
ctx.font = "50px Arial";
ctx.fillText("Work in progress", 330, 330);
