var client = new WebSocket('ws://mami1.markab.uberspace.de:61788', 'echo-protocol');
var playerNB = 0;

function sendMessage(msg)
{
  client.send(JSON.stringify(msg));
}

client.onerror = function()
{
    console.log('Connection Error');
}

client.onopen = function()
{

    console.log('WebSocket Client Connected');
    startGame();

}

client.onclose = function()
{
    console.log('echo-protocol Client Closed');
}

client.onmessage = function(e)
{
    if (typeof e.data === 'string')
    {
      var data = JSON.parse(e.data);
      switch (data.type)
      {
        case "CHANGE":
          receiveDirection(data.content);
          break;
        case "PLAYER_CONNECTED":
        case "RESET":
          reset();
          break;
        case "YOU_ARE_PLAYER":
          playerNB = data.content.player;
          break;
        default:

      }
    }
}
