# Projects
Auf den drei Raspberry Pis l�uft eine komplette Webaplikation mit einem Node.js Server, einem Apache und einem MySQL Server. 
